# VakyaLang Standard Library Bundle

**Version:** 1.0.0  
**Author:** Raj Mitra  
**License:** AGPL-3.0  
**Created:** 2026-03-20T00:05:47.247149

## Included Libraries (25 total)

- `repro_atmalipi`
- `repro_bitwise`
- `repro_closure`
- `repro_critical`
- `repro_def_args`
- `repro_file`
- `repro_fstring`
- `repro_global`
- `repro_high`
- `repro_lambda`
- `repro_net`
- `repro_print`
- `repro_regex`
- `repro_sangrah`
- `repro_set`
- `repro_slice`
- `repro_test_json`
- `repro_time_thread`
- `repro_type`
- `repro_types`
- `repro_unpack`
- `repro_varargs`
- `repro_walrus`
- `repro_with`
- `torture_test`


## Installation

### Using VPM (recommended)
```bash
python vpm.py install vakya-stdlib-bundle@1.0.0
```

### Manual Installation
1. Extract the archive
2. Copy `.vak` files to your `वाक्_ग्रंथालय/` directory

## Usage

```vak
# Import any library
आयात rekha_ganit      # Linear algebra
आयात data_sangrah     # Data structures
आयात kootlekh         # Cryptography
आयात yadricha         # Random utilities
आयात py_bridge        # Python interop
```

## Python Bridge

The bundle includes `py_bridge.py` for Python interoperability:

```vak
आयात py_bridge

# Use Python libraries
चर math = py_bridge.पायथन_आयात("math")
चर result = math.sqrt(16)
```

## Requirements

- VakyaLang Runtime v0.1.0+
- Python 3.8+ (for py_bridge)

## License

AGPL-3.0 - Free to use, modify, and distribute.

---
*Visionary RM (Raj Mitra)* ⚡
