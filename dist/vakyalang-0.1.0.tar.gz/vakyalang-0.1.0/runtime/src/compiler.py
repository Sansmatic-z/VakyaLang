# वाक् भाषा - संकलक (Compiler)
# Vak Language - AST to Bytecode Compiler

from typing import Any, Optional
from .bytecode import Bytecode
from .opcodes import OpCode
from .ast_nodes import *


class Compiler:
    """
    Compiles VakyaLang AST into bytecode.

    Single-pass compiler with jump patching.
    Maintains variable scope and constant pool.

    Compilation phases:
    1. Macro Expansion (सूत्र विस्तार) - Expand compile-time macros
    2. Constant Folding (स्थिर गुड़न) - Optimize constant expressions
    3. Bytecode Generation - Convert AST to bytecode
    4. Dead Code Elimination (मृत कोड उन्मूलन) - Remove unreachable code
    """

    def __init__(self, optimize: bool = True):
        self.bytecode = Bytecode()
        self.loop_stack = []  # For break/continue
        self.optimize = optimize  # Enable/disable optimizations

    def compile(self, node: Node) -> Bytecode:
        """
        Compile AST node to bytecode.

        Phases:
        1. MACRO EXPANSION: Expand all सूत्र (macros) before bytecode generation
        2. CONSTANT FOLDING: Optimize constant expressions at compile-time
        3. BYTECODE GENERATION: Convert optimized AST to bytecode
        4. DEAD CODE ELIMINATION: Remove unreachable bytecode instructions
        """
        import math

        # ─────────────────────────────────────────────────────────────────────
        # PHASE 1: MACRO EXPANSION (सूत्र विस्तार)
        # ─────────────────────────────────────────────────────────────────────
        # Expand all macros BEFORE bytecode generation
        # This is compile-time transformation - no runtime overhead
        if isinstance(node, Program):
            from .macro_expander import MacroExpander
            expander = MacroExpander()
            node = expander.expand(node)

        # ─────────────────────────────────────────────────────────────────────
        # PHASE 2: CONSTANT FOLDING (स्थिर गुड़न) - Optional optimization
        # ─────────────────────────────────────────────────────────────────────
        if self.optimize:
            node = self._constant_fold(node)

        # ─────────────────────────────────────────────────────────────────────
        # PHASE 3: BYTECODE GENERATION
        # ─────────────────────────────────────────────────────────────────────

        # Inject PI constant
        pi_idx = self.bytecode.add_constant(math.pi)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, pi_idx)
        pi_slot = self.bytecode.get_var_slot('पाई')
        self.bytecode.emit(OpCode.STORE_VAR, pi_slot)

        self._compile_node(node)
        self.bytecode.emit(OpCode.HALT)
        
        # ─────────────────────────────────────────────────────────────────────
        # PHASE 4: DEAD CODE ELIMINATION (मृत कोड उन्मूलन) - Optional
        # ─────────────────────────────────────────────────────────────────────
        if self.optimize:
            self._eliminate_dead_code()
        
        return self.bytecode

    def _compile_node(self, node: Node):
        """Dispatch to appropriate compile method."""
        method_name = f'_compile_{type(node).__name__}'
        method = getattr(self, method_name, self._compile_generic)
        method(node)

    def _compile_generic(self, node: Node):
        """Fallback for unhandled nodes."""
        raise CompileError(f"Cannot compile {type(node).__name__}", node.line)

    def _compile_Program(self, node: Program):
        for stmt in node.body:
            self._compile_node(stmt)

    def _compile_VarDecl(self, node: VarDecl):
        if node.value:
            self._compile_node(node.value)
        else:
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, self.bytecode.add_constant(None))

        if len(node.names) == 1:
            slot = self.bytecode.get_var_slot(node.names[0])
            self.bytecode.emit(OpCode.STORE_VAR, slot)
        else:
            self.bytecode.emit(OpCode.UNPACK_SEQUENCE, len(node.names))
            for name in node.names:
                slot = self.bytecode.get_var_slot(name)
                self.bytecode.emit(OpCode.STORE_VAR, slot)

    def _compile_ConstDecl(self, node: ConstDecl):
        self._compile_node(node.value)
        slot = self.bytecode.get_var_slot(node.name)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

    def _compile_GlobalStmt(self, node: GlobalStmt):
        for name in node.names:
            self.bytecode.global_names.add(name)
            # Ensure it has a slot so STORE_VAR/LOAD_VAR work
            self.bytecode.get_var_slot(name)

    def _compile_NonlocalStmt(self, node: NonlocalStmt):
        # For now, treat nonlocal as global or just record it
        # True nonlocal requires upvalue tracking
        pass

    def _compile_FuncDecl(self, node: FuncDecl):
        """
        Compile function declaration with Vibhakti semantic role support.

        If function has Vibhakti-decorated parameters:
        1. Build VibhaktiSignature object
        2. Register with VibhaktiRegistry
        3. Emit CHECK_VIBHAKTI opcode at function entry
        """
        from .ast_nodes import VibhaktiParam
        from .vibhakti import VibhaktiSignature, VibhaktiCase, VIBHAKTI_KEYWORDS, VibhaktiRegistry

        # Create separate bytecode for function
        func_compiler = Compiler()
        func_compiler.bytecode.name = node.name
        func_compiler.bytecode.is_async = node.is_async  # Mark as async coroutine

        # Build Vibhakti signature if parameters have Vibhakti roles
        vibhakti_sig = None
        has_vibhakti = any(isinstance(p, VibhaktiParam) for p in node.params)

        if has_vibhakti:
            vibhakti_sig = VibhaktiSignature()

            # Process parameters - convert VibhaktiParam to VibhaktiSignature
            for param in node.params:
                if isinstance(param, VibhaktiParam):
                    from .vibhakti import create_vibhakti_param
                    v_param = create_vibhakti_param(
                        name=param.name,
                        vibhakti_name=param.vibhakti,
                        type_hint=param.type_hint,
                        default=param.default,
                        line=param.line
                    )
                    vibhakti_sig.add_param(v_param)
                    func_compiler.bytecode.get_var_slot(param.name)
                    func_compiler.bytecode.param_names.append(param.name)
                    if param.type_hint:
                        func_compiler.bytecode.type_hints[param.name] = param.type_hint
                else:
                    # Regular parameter tuple
                    p_name = param[0] if isinstance(param, tuple) else param
                    p_type = param[1] if isinstance(param, tuple) else None
                    func_compiler.bytecode.get_var_slot(p_name)
                    func_compiler.bytecode.param_names.append(p_name)
                    if p_type:
                        func_compiler.bytecode.type_hints[p_name] = p_type

            # Register signature
            registry = VibhaktiRegistry()
            registry.register(node.name, vibhakti_sig)

        # Handle parameters (non-Vibhakti)
        if not has_vibhakti:
            for param_pair in node.params:
                p_name = param_pair[0] if isinstance(param_pair, tuple) else param_pair
                p_type = param_pair[1] if isinstance(param_pair, tuple) else None
                func_compiler.bytecode.get_var_slot(p_name)
                func_compiler.bytecode.param_names.append(p_name)
                if p_type:
                    func_compiler.bytecode.type_hints[p_name] = p_type

        func_compiler.bytecode.num_params = len(node.params)

        # Handle variadic argument
        if node.varargs:
            func_compiler.bytecode.varargs_name = node.varargs
            func_compiler.bytecode.get_var_slot(node.varargs)

        # Handle default values
        for default_node in node.defaults:
            if default_node is None:
                func_compiler.bytecode.defaults.append(None)
            elif isinstance(default_node, (NumberLiteral, StringLiteral, BoolLiteral, NullLiteral)):
                func_compiler.bytecode.defaults.append(getattr(default_node, 'value', None))
            else:
                func_compiler.bytecode.defaults.append(None)

        # Compile function body
        func_compiler._compile_node(node.body)

        # Ensure function returns
        if not func_compiler.bytecode.code or func_compiler.bytecode.code[-1] != OpCode.RETURN.value:
            func_compiler.bytecode.emit_16bit(OpCode.LOAD_CONST, func_compiler.bytecode.add_constant(None))
            func_compiler.bytecode.emit(OpCode.RETURN)

        # Store function bytecode and flatten inner functions
        self.bytecode.functions[node.name] = func_compiler.bytecode
        self.bytecode.functions.update(func_compiler.bytecode.functions)

        # Load function reference with environment capture
        env = {name: None for name in self.bytecode.var_names}

        # Mark function as coroutine if async
        if node.is_async:
            idx = self.bytecode.add_constant(('coroutine', node.name, env))
        else:
            idx = self.bytecode.add_constant(('function', node.name, env))

        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)
        slot = self.bytecode.get_var_slot(node.name)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

    def _compile_LambdaExpr(self, node: LambdaExpr):
        # Generate a unique name for the lambda
        lambda_name = f"<lambda_{id(node)}>"

        func_compiler = Compiler()
        func_compiler.bytecode.name = lambda_name

        # Add parameters
        for param_pair in node.params:
            p_name = param_pair[0] if isinstance(param_pair, tuple) else param_pair
            p_type = param_pair[1] if isinstance(param_pair, tuple) else None
            func_compiler.bytecode.get_var_slot(p_name)
            if p_type:
                func_compiler.bytecode.type_hints[p_name] = p_type
        func_compiler.bytecode.num_params = len(node.params)

        # Handle variadic argument
        if node.varargs:
            func_compiler.bytecode.varargs_name = node.varargs
            func_compiler.bytecode.get_var_slot(node.varargs)

        # Compile body (which is a Block containing a ReturnStmt)
        func_compiler._compile_node(node.body)

        # Ensure return
        if not func_compiler.bytecode.code or func_compiler.bytecode.code[-1] != OpCode.RETURN.value:
            func_compiler.bytecode.emit_16bit(OpCode.LOAD_CONST, func_compiler.bytecode.add_constant(None))
            func_compiler.bytecode.emit(OpCode.RETURN)

        # Store in parent
        self.bytecode.functions[lambda_name] = func_compiler.bytecode
        self.bytecode.functions.update(func_compiler.bytecode.functions)

        # Push function tuple to stack with environment capture
        env = {name: None for name in self.bytecode.var_names}
        idx = self.bytecode.add_constant(('function', lambda_name, env))
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

    def _compile_ReturnStmt(self, node: ReturnStmt):
        if node.value:
            self._compile_node(node.value)
            self.bytecode.emit(OpCode.RETURN)
        else:
            self.bytecode.emit(OpCode.RETURN_VOID)

    def _compile_PrintStmt(self, node: PrintStmt):
        for i, val in enumerate(node.values):
            if i > 0:
                # Load space separator
                idx = self.bytecode.add_constant(' ')
                self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)
                self.bytecode.emit(OpCode.PRINT)
            self._compile_node(val)
            self.bytecode.emit(OpCode.PRINT)
        # Print newline
        idx = self.bytecode.add_constant('\n')
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)
        self.bytecode.emit(OpCode.PRINT)

    def _compile_IfStmt(self, node: IfStmt):
        end_jumps = []

        self._compile_node(node.condition)
        jump_next = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)
        self._compile_node(node.then_body)
        end_jumps.append(self.bytecode.get_current_offset())
        self.bytecode.emit_16bit(OpCode.JUMP, 0)
        self.bytecode.patch_jump(jump_next, self.bytecode.get_current_offset())

        for elif_cond, elif_body in node.elif_clauses:
            self._compile_node(elif_cond)
            jump_next = self.bytecode.get_current_offset()
            self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)
            self._compile_node(elif_body)
            end_jumps.append(self.bytecode.get_current_offset())
            self.bytecode.emit_16bit(OpCode.JUMP, 0)
            self.bytecode.patch_jump(jump_next, self.bytecode.get_current_offset())

        if node.else_body:
            self._compile_node(node.else_body)

        end_offset = self.bytecode.get_current_offset()
        for jump_end in end_jumps:
            self.bytecode.patch_jump(jump_end, end_offset)

    def _compile_WhileStmt(self, node: WhileStmt):
        loop_start = self.bytecode.get_current_offset()

        # Compile condition
        self._compile_node(node.condition)

        # Jump to end if false
        jump_end = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)

        # Track loop for break/continue
        loop_ctx = {
            "continue_target": loop_start,
            "break_patches": [],
            "break_cleanup_ops": 0,
        }
        self.loop_stack.append(loop_ctx)

        # Compile body
        self._compile_node(node.body)

        loop_ctx = self.loop_stack.pop()

        # Jump back to start
        current_pos = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP, loop_start - (current_pos + 3))

        # Patch end jump
        end_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_end, end_offset)
        for break_jump in loop_ctx["break_patches"]:
            self.bytecode.patch_jump(break_jump, end_offset)

    def _compile_ForStmt(self, node: ForStmt):
        # 1. Compile iterable and get iterator
        self._compile_node(node.iterable)
        self.bytecode.emit(OpCode.GET_ITER)

        loop_start = self.bytecode.get_current_offset()

        # 2. Iteration step
        jump_end = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.FOR_ITER, 0) # Placeholder

        # 3. Store current item in the loop variable
        var_slot = self.bytecode.get_var_slot(node.var_name)
        self.bytecode.emit(OpCode.STORE_VAR, var_slot)

        # 4. Compile body
        loop_ctx = {
            "continue_target": loop_start,
            "break_patches": [],
            "break_cleanup_ops": 1,
        }
        self.loop_stack.append(loop_ctx)
        self._compile_node(node.body)
        loop_ctx = self.loop_stack.pop()

        # 5. Loop back
        # The jump back is from the current position to the start of FOR_ITER
        # vm.py: pc += 3 + offset
        current_pos = self.bytecode.get_current_offset()
        back_jump_dist = loop_start - (current_pos + 3)
        self.bytecode.emit_16bit(OpCode.JUMP, back_jump_dist)

        # 6. Patch the FOR_ITER exit jump
        # This will jump past the back-jump instruction
        loop_end = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_end, loop_end)
        for break_jump in loop_ctx["break_patches"]:
            self.bytecode.patch_jump(break_jump, loop_end)

    def _compile_BreakStmt(self, node: BreakStmt):
        if not self.loop_stack:
            raise CompileError("विराम (break) outside loop", node.line)
        for _ in range(self.loop_stack[-1]["break_cleanup_ops"]):
            self.bytecode.emit(OpCode.POP)
        jump_pos = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP, 0)  # Patched at loop exit
        self.loop_stack[-1]["break_patches"].append(jump_pos)

    def _compile_ContinueStmt(self, node: ContinueStmt):
        if not self.loop_stack:
            raise CompileError("अग्रे (continue) outside loop", node.line)
        loop_start = self.loop_stack[-1]["continue_target"]
        self.bytecode.emit_16bit(OpCode.JUMP, loop_start - (self.bytecode.get_current_offset() + 3))

    def _compile_ClassDecl(self, node: ClassDecl):
        # We need to compile the class body into a dictionary of methods/attributes
        class_compiler = Compiler()
        class_compiler.bytecode.name = f"<class {node.name}>"

        # Compile methods inside the class body
        if hasattr(node.body, 'stmts'):
            for stmt in node.body.stmts:
                class_compiler._compile_node(stmt)

        # Ensure it returns
        class_compiler.bytecode.emit(OpCode.RETURN_VOID)

        # Store class initialization bytecode
        self.bytecode.functions[node.name] = class_compiler.bytecode

        # Push parent class if any, else None
        if hasattr(node, 'superclass') and node.superclass:
            if isinstance(node.superclass, IdentifierExpr):
                slot = self.bytecode.get_var_slot(node.superclass.name)
                self.bytecode.emit(OpCode.LOAD_VAR, slot)
            else:
                self._compile_node(node.superclass)
        else:
            idx = self.bytecode.add_constant(None)
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

        # Push class name
        idx = self.bytecode.add_constant(node.name)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

        # Emit BUILD_CLASS
        self.bytecode.emit(OpCode.BUILD_CLASS)

        slot = self.bytecode.get_var_slot(node.name)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

    def _compile_TryStmt(self, node: TryStmt):
        # Setup exception handler jump
        jump_catch = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.SETUP_EXCEPT, 0) # Placeholder for catch block

        # Compile try block
        self._compile_node(node.try_body)

        # Pop exception handler if try succeeded
        self.bytecode.emit(OpCode.POP_EXCEPT)

        # Jump over catch block
        jump_end = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP, 0)

        # Patch exception jump to here (Start of catch block)
        catch_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_catch, catch_offset)

        if node.catch_body:
            if node.catch_var:
                # The exception object is pushed to stack by the VM
                slot = self.bytecode.get_var_slot(node.catch_var)
                self.bytecode.emit(OpCode.STORE_VAR, slot)
            else:
                self.bytecode.emit(OpCode.POP) # Discard exception object
            self._compile_node(node.catch_body)

        # Patch end jump to here (After catch block)
        end_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_end, end_offset)

        if node.finally_body:
            self._compile_node(node.finally_body)

    def _compile_WithStmt(self, node: WithStmt):
        # Evaluate context manager
        self._compile_node(node.expr)

        # Store in hidden local for cleanup
        hidden_name = f"<ctx_{id(node)}>"
        slot = self.bytecode.get_var_slot(hidden_name)
        self.bytecode.emit(OpCode.DUP)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

        # The bound name inside the block should receive __enter__().
        self.bytecode.emit(OpCode.DUP)
        enter_idx = self.bytecode.add_constant('__enter__')
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, enter_idx)
        self.bytecode.emit(OpCode.CALL_METHOD, 0)

        # Store in user variable if provided
        if node.var_name:
            user_slot = self.bytecode.get_var_slot(node.var_name)
            self.bytecode.emit(OpCode.STORE_VAR, user_slot)
        else:
            self.bytecode.emit(OpCode.POP)

        # Execute body
        self._compile_node(node.body)

        # Load for cleanup
        self.bytecode.emit(OpCode.LOAD_VAR, slot)
        self.bytecode.emit(OpCode.WITH_CLEANUP)

    def _compile_ThrowStmt(self, node: ThrowStmt):
        self._compile_node(node.value)
        self.bytecode.emit(OpCode.THROW)

    def _compile_ImportStmt(self, node: ImportStmt):
        idx = self.bytecode.add_constant(node.module)
        self.bytecode.emit_16bit(OpCode.IMPORT_NAME, idx)

        if node.names:
            temp_slot = self.bytecode.get_var_slot(f"__imported_module_{node.line}")
            self.bytecode.emit(OpCode.STORE_VAR, temp_slot)

            for name in node.names:
                self.bytecode.emit(OpCode.LOAD_VAR, temp_slot)
                attr_idx = self.bytecode.add_constant(name)
                self.bytecode.emit_16bit(OpCode.ATTR_GET, attr_idx)
                slot = self.bytecode.get_var_slot(name)
                self.bytecode.emit(OpCode.STORE_VAR, slot)
        else:
            # Store module object in local variable
            slot = self.bytecode.get_var_slot(node.module)
            self.bytecode.emit(OpCode.STORE_VAR, slot)
            
    def _compile_Block(self, node: Block):
        for stmt in node.stmts:
            self._compile_node(stmt)

    def _compile_ExprStmt(self, node: ExprStmt):
        self._compile_node(node.expr)
        self.bytecode.emit(OpCode.POP)  # Discard result

    def _compile_BinaryExpr(self, node: BinaryExpr):
        self._compile_node(node.left)
        self._compile_node(node.right)

        op_map = {
            '+': OpCode.ADD,
            '-': OpCode.SUB,
            '*': OpCode.MUL,
            '/': OpCode.DIV,
            '//': OpCode.IDIV,  # Integer division
            '%': OpCode.MOD,
            '**': OpCode.POW,
            '&': OpCode.BAND,
            '|': OpCode.BOR,
            '^': OpCode.BXOR,
            '<<': OpCode.LSHIFT,
            '>>': OpCode.RSHIFT,
            '==': OpCode.EQ,
            '!=': OpCode.NEQ,
            '<': OpCode.LT,
            '>': OpCode.GT,
            '<=': OpCode.LTE,
            '>=': OpCode.GTE,
            'और': OpCode.AND,
            'अथवा': OpCode.OR,
            'अन्तर्गत': OpCode.CONTAINS,  # Membership test
        }

        if node.op == 'not in':
            self.bytecode.emit(OpCode.CONTAINS)
            self.bytecode.emit(OpCode.NOT)
        elif node.op in op_map:
            self.bytecode.emit(op_map[node.op])
        else:
            raise CompileError(f"Unknown operator: {node.op}", node.line)

    def _compile_UnaryExpr(self, node: UnaryExpr):
        self._compile_node(node.operand)

        if node.op == '-':
            self.bytecode.emit(OpCode.NEG)
        elif node.op == 'न':
            self.bytecode.emit(OpCode.NOT)
        elif node.op == '~':
            self.bytecode.emit(OpCode.BNOT)
        else:
            raise CompileError(f"Unknown unary operator: {node.op}", node.line)

    def _compile_ConditionalExpr(self, node: ConditionalExpr):
        self._compile_node(node.condition)

        jump_else = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)

        self._compile_node(node.then_expr)

        jump_end = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.JUMP, 0)

        else_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_else, else_offset)

        self._compile_node(node.else_expr)

        end_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_end, end_offset)
            
    def _compile_AssignExpr(self, node: AssignExpr):
        # Determine value to store
        if node.op == '=':
            self._compile_node(node.value)
        else:
            # Compound assignment (+=, -=, etc.)
            # First load the current value
            if isinstance(node.target, IdentifierExpr):
                slot = self.bytecode.get_var_slot(node.target.name)
                self.bytecode.emit(OpCode.LOAD_VAR, slot)
            elif isinstance(node.target, IndexExpr):
                self._compile_node(node.target.obj)
                self._compile_node(node.target.index)
                self.bytecode.emit(OpCode.INDEX_GET)
            elif isinstance(node.target, MemberExpr):
                self._compile_node(node.target.obj)
                idx = self.bytecode.add_constant(node.target.attr)
                self.bytecode.emit_16bit(OpCode.ATTR_GET, idx)

            # Compile right side value
            self._compile_node(node.value)

            # Apply operator
            op_map = {'+=': OpCode.ADD, '-=': OpCode.SUB, '*=': OpCode.MUL, '/=': OpCode.DIV, '%=': OpCode.MOD, ':=': None}
            if node.op in op_map:
                if op_map[node.op]:
                    self.bytecode.emit(op_map[node.op])
            else:
                raise CompileError(f"Unknown assignment operator: {node.op}", node.line)

        # Store the computed value
        if isinstance(node.target, IdentifierExpr):
            slot = self.bytecode.get_var_slot(node.target.name)
            self.bytecode.emit(OpCode.STORE_VAR, slot)
            self.bytecode.emit(OpCode.LOAD_VAR, slot)  # Assignment returns value
        elif isinstance(node.target, IndexExpr):
            # Target stack needs to be: obj, index, value
            # But value is currently on top.
            # We need to temporarily pop value, push obj, push index, push value

            # Since our ISA doesn't have deep stack manipulation, we can use a temp variable
            temp_val_slot = self.bytecode.get_var_slot("__temp_assign_val")
            self.bytecode.emit(OpCode.STORE_VAR, temp_val_slot)

            self._compile_node(node.target.obj)
            self._compile_node(node.target.index)
            self.bytecode.emit(OpCode.LOAD_VAR, temp_val_slot)

            self.bytecode.emit(OpCode.INDEX_SET)
            self.bytecode.emit(OpCode.LOAD_VAR, temp_val_slot) # Return value
        elif isinstance(node.target, MemberExpr):
            temp_val_slot = self.bytecode.get_var_slot("__temp_assign_val")
            self.bytecode.emit(OpCode.STORE_VAR, temp_val_slot)

            self._compile_node(node.target.obj)
            self.bytecode.emit(OpCode.LOAD_VAR, temp_val_slot)

            idx = self.bytecode.add_constant(node.target.attr)
            self.bytecode.emit_16bit(OpCode.ATTR_SET, idx)

            self.bytecode.emit(OpCode.LOAD_VAR, temp_val_slot) # Return value
        else:
            raise CompileError("Invalid assignment target", node.line)

    def _compile_CallExpr(self, node: CallExpr):
        is_method_call = isinstance(node.callee, MemberExpr)

        # Compile callee FIRST
        if isinstance(node.callee, IdentifierExpr):
            slot = self.bytecode.get_var_slot(node.callee.name)
            self.bytecode.emit(OpCode.LOAD_VAR, slot)
        elif is_method_call:
            # MemberExpr: push obj, then push attr string
            self._compile_node(node.callee.obj)
            idx = self.bytecode.add_constant(node.callee.attr)
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)
        else:
            self._compile_node(node.callee)

        # Compile arguments left-to-right
        for arg in node.args:
            self._compile_node(arg)

        if node.kwargs:
            for key, value in node.kwargs.items():
                self._compile_node(value)
                idx = self.bytecode.add_constant(key)
                self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)
            self.bytecode.emit(OpCode.BUILD_DICT, len(node.kwargs))

        if is_method_call:
            self.bytecode.emit(OpCode.CALL_METHOD_KW if node.kwargs else OpCode.CALL_METHOD, len(node.args))
        else:
            self.bytecode.emit(OpCode.CALL_KW if node.kwargs else OpCode.CALL, len(node.args))

    def _compile_MemberExpr(self, node: MemberExpr):
        self._compile_node(node.obj)
        idx = self.bytecode.add_constant(node.attr)
        self.bytecode.emit_16bit(OpCode.ATTR_GET, idx)

    def _compile_IndexExpr(self, node: IndexExpr):
        self._compile_node(node.obj)
        self._compile_node(node.index)
        self.bytecode.emit(OpCode.INDEX_GET)

    def _compile_SliceExpr(self, node: SliceExpr):
        self._compile_node(node.obj)

        if node.start:
            self._compile_node(node.start)
        else:
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, self.bytecode.add_constant(None))

        if node.stop:
            self._compile_node(node.stop)
        else:
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, self.bytecode.add_constant(None))

        if node.step:
            self._compile_node(node.step)
        else:
            self.bytecode.emit_16bit(OpCode.LOAD_CONST, self.bytecode.add_constant(None))

        self.bytecode.emit(OpCode.MAKE_SLICE)
        self.bytecode.emit(OpCode.INDEX_GET)

    def _compile_IdentifierExpr(self, node: IdentifierExpr):
        slot = self.bytecode.get_var_slot(node.name)
        self.bytecode.emit(OpCode.LOAD_VAR, slot)

    def _compile_NumberLiteral(self, node: NumberLiteral):
        idx = self.bytecode.add_constant(node.value)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

    def _compile_StringLiteral(self, node: StringLiteral):
        idx = self.bytecode.add_constant(node.value)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

    def _compile_FStringExpr(self, node: FStringExpr):
        for part in node.parts:
            self._compile_node(part)
        self.bytecode.emit(OpCode.BUILD_STRING, len(node.parts))

    def _compile_BoolLiteral(self, node: BoolLiteral):
        idx = self.bytecode.add_constant(node.value)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

    def _compile_NullLiteral(self, node: NullLiteral):
        idx = self.bytecode.add_constant(None)
        self.bytecode.emit_16bit(OpCode.LOAD_CONST, idx)

    def _compile_ListLiteral(self, node: ListLiteral):
        for el in node.elements:
            self._compile_node(el)
        self.bytecode.emit(OpCode.BUILD_LIST, len(node.elements))

    def _compile_TupleLiteral(self, node: TupleLiteral):
        for el in node.elements:
            self._compile_node(el)
        self.bytecode.emit(OpCode.BUILD_TUPLE, len(node.elements))

    def _compile_ListComp(self, node: ListComp):
        # Create an empty list
        self.bytecode.emit(OpCode.BUILD_LIST, 0)

        # Evaluate iterable and get iterator
        self._compile_node(node.iterable)
        self.bytecode.emit(OpCode.GET_ITER)

        # Loop start
        loop_start = self.bytecode.get_current_offset()
        jump_exit = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.FOR_ITER, 0)

        # Store loop variable
        slot = self.bytecode.get_var_slot(node.var_name)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

        filter_jump = None
        if node.filter_expr is not None:
            self._compile_node(node.filter_expr)
            filter_jump = self.bytecode.get_current_offset()
            self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)

        # Evaluate expression
        self._compile_node(node.expr)

        # Append to list (stack: [... list, iter, val])
        # We need to rearrange stack or use a specific LIST_APPEND that expects this
        # Actually, LIST_APPEND pops val, and assumes list is at stack[-2].
        # But wait, stack is: list, iter, val.
        # So LIST_APPEND needs to operate on stack[-3]. Let's just emit SWAP, then rot? No.
        # Let's fix LIST_APPEND in VM to append stack[-1] to stack[-3].
        self.bytecode.emit(OpCode.LIST_APPEND)

        if filter_jump is not None:
            self.bytecode.patch_jump(filter_jump, self.bytecode.get_current_offset())

        # Jump to loop start
        jump_dist = loop_start - (self.bytecode.get_current_offset() + 3)
        if jump_dist < 0:
            jump_dist += 65536
        self.bytecode.emit_16bit(OpCode.JUMP, jump_dist)

        # Patch exit
        exit_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_exit, exit_offset)

    def _compile_DictComp(self, node: DictComp):
        dict_slot = self.bytecode.get_var_slot(f"__dict_comp_{id(node)}")
        self.bytecode.emit(OpCode.BUILD_DICT, 0)
        self.bytecode.emit(OpCode.STORE_VAR, dict_slot)

        self._compile_node(node.iterable)
        self.bytecode.emit(OpCode.GET_ITER)

        loop_start = self.bytecode.get_current_offset()
        jump_exit = self.bytecode.get_current_offset()
        self.bytecode.emit_16bit(OpCode.FOR_ITER, 0)

        slot = self.bytecode.get_var_slot(node.var_name)
        self.bytecode.emit(OpCode.STORE_VAR, slot)

        filter_jump = None
        if node.filter_expr is not None:
            self._compile_node(node.filter_expr)
            filter_jump = self.bytecode.get_current_offset()
            self.bytecode.emit_16bit(OpCode.JUMP_IF_FALSE, 0)

        self.bytecode.emit(OpCode.LOAD_VAR, dict_slot)
        self._compile_node(node.key_expr)
        self._compile_node(node.value_expr)
        self.bytecode.emit(OpCode.INDEX_SET)

        if filter_jump is not None:
            self.bytecode.patch_jump(filter_jump, self.bytecode.get_current_offset())

        jump_dist = loop_start - (self.bytecode.get_current_offset() + 3)
        if jump_dist < 0:
            jump_dist += 65536
        self.bytecode.emit_16bit(OpCode.JUMP, jump_dist)

        exit_offset = self.bytecode.get_current_offset()
        self.bytecode.patch_jump(jump_exit, exit_offset)
        self.bytecode.emit(OpCode.LOAD_VAR, dict_slot)

    def _compile_DictLiteral(self, node: DictLiteral):
        for key, val in node.pairs:
            self._compile_node(val)
            self._compile_node(key)
        self.bytecode.emit(OpCode.BUILD_DICT, len(node.pairs))

    def _compile_SetLiteral(self, node: SetLiteral):
        for el in node.elements:
            self._compile_node(el)
        self.bytecode.emit(OpCode.BUILD_SET, len(node.elements))

    def _compile_AwaitExpr(self, node: AwaitExpr):
        """
        Compile await expression (प्रतीक्षा).

        The await keyword suspends the coroutine until the awaited
        coroutine completes, then pushes the result onto the stack.
        """
        # Compile the operand (should be a coroutine)
        self._compile_node(node.operand)
        # Emit AWAIT opcode to suspend and wait for result
        self.bytecode.emit(OpCode.AWAIT)

    def _compile_ProofDeclaration(self, node: ProofDeclaration):
        """
        Compile Nyāya proof declaration (सिद्धि).

        At compile-time:
        1. Verify the proof with NyayaProofVerifier + Sansmatic
        2. Embed a verifiable certificate payload in bytecode
        3. Emit VERIFY_PROOF so runtime can reject tampered certificates
        """
        from .nyaya_verifier import NyayaProofVerifier

        verifier = NyayaProofVerifier()
        certificate = verifier.verify_proof(
            node.statement,
            node.evidence_body,
            statement_expr=getattr(node, 'statement_expr', None),
            certificate_hint=node.certificate,
        )

        if not certificate.verified:
            reason = certificate.reason or "unproven statement"
            raise CompileError(
                f"सिद्धि असफल: {node.statement} ({reason})",
                node.line,
            )

        cert_idx = self.bytecode.add_constant(certificate.payload)
        self.bytecode.emit_16bit(OpCode.VERIFY_PROOF, cert_idx)
        self.bytecode.emit(OpCode.POP)

    def _get_builtin_index(self, name: str) -> int:
        """Get index of builtin function."""
        builtins_list = [
            'पाठ_कर', 'str', 'परास', 'range', 'दीर्घता', 'len', 'प्रकार', 'type',
            'संख्या', 'int', 'दशमलव', 'float', 'मुद्रय', 'print',
            'पठन', 'लेखन', 'खोलो', 'अस्तित्व', 'मिटाओ', 'सूची_निर्देशिका', 'बनाओ_निर्देशिका',
            'परिवेश_प्राप्त', 'परिवेश_सेट', 'प्रणाली_कमांड', 'मंच', 'कार्य_निर्देशिका',
            'संयोग', 'विभाजन', 'छाँटो', 'उच्च', 'निम्न', 'पूर्णांक_कर',
            'क्रमबद्ध', 'योग', 'अधिकतम', 'न्यूनतम', 'कुंजियाँ', 'मान', 'वर्गमूल',
            'परम',  # Added: absolute value for ganit module
            '_math_cos', '_math_sin', '_math_tan', '_math_sqrt', '_math_abs',
            '_math_floor', '_math_ceil', '_math_round', '_math_degrees', '_math_radians',
            'जाल_लाओ', 'जाल_भेजो', 'जाल_डाउनलोड', 'जाल_पुट', 'जाल_हटाओ',  # Added: जाल_हटाओ (HTTP DELETE)
            'समय', 'निद्रा', 'धागा_शुरू',
            'सेट_टाइमआउट', 'सेट_इंटरवल', 'क्लियर_टाइमआउट', 'async_sleep',
            'रेगेक्स_खोज', 'रेगेक्स_बदलो', 'जेसन_लिखो', 'जेसन_पढ़ो',
            'परिभाषय', 'दावा', 'नियम', 'मूल्यांकन', 'सिद्ध_है', 'प्रमाण_लॉग', 'प्रमाण_रीसेट',
            'आत्म_मूल्य', 'भाव_पढ़ो', 'अवस्था_पढ़ो', 'सभी_भाव', 'सभी_अवस्था', 'आत्म_इतिहास', 'आत्म_है', 'आत्म_भाव', 'आत्म_अवस्था', 'आत्म_मूल',
            '_chitra_canvas', '_chitra_fill', '_chitra_point', '_chitra_line', '_chitra_circle',
            '_chitra_rect', '_chitra_polygon', '_chitra_text', '_chitra_save', '_chitra_load',
            '_chitra_color', '_chitra_colors', '_chitra_width', '_chitra_height',
            '_chitra_pixel_get', '_chitra_pixel_set', '_chitra_clear', '_chitra_text_centered',
            '_chitra_gradient', '_chitra_rotate', '_chitra_mandala', '_chitra_kaleidoscope',
            'पायथन_आयात', 'पायथन_चलाओ', 'पायथन_मूल्यांकन', 'अक्षर_मान'
        ]
        try:
            return builtins_list.index(name)
        except ValueError:
            return 0

    # ─────────────────────────────────────────────────────────────────────────
    # OPTIMIZATION PHASES
    # ─────────────────────────────────────────────────────────────────────────

    def _constant_fold(self, node: Node) -> Node:
        """
        Constant folding optimization (स्थिर गुड़न).

        Evaluates constant expressions at compile-time instead of runtime.
        
        Examples:
        - 2 + 3 → 5
        - 10 * 5 → 50
        - "hello" + " " + "world" → "hello world"
        
        Args:
            node: AST node to optimize
            
        Returns:
            Optimized AST node
        """
        if isinstance(node, BinaryExpr):
            # Recursively fold left and right operands
            left = self._constant_fold(node.left)
            right = self._constant_fold(node.right)
            
            # Check if both operands are constants
            if isinstance(left, NumberLiteral) and isinstance(right, NumberLiteral):
                # Fold arithmetic operations
                try:
                    if node.op == '+':
                        return NumberLiteral(left.value + right.value, line=node.line)
                    elif node.op == '-':
                        return NumberLiteral(left.value - right.value, line=node.line)
                    elif node.op == '*':
                        return NumberLiteral(left.value * right.value, line=node.line)
                    elif node.op == '/':
                        if right.value != 0:
                            return NumberLiteral(left.value / right.value, line=node.line)
                    elif node.op == '//':
                        if right.value != 0:
                            return NumberLiteral(left.value // right.value, line=node.line)
                    elif node.op == '%':
                        if right.value != 0:
                            return NumberLiteral(left.value % right.value, line=node.line)
                    elif node.op == '**':
                        return NumberLiteral(left.value ** right.value, line=node.line)
                    elif node.op == '==':
                        return BoolLiteral(left.value == right.value, line=node.line)
                    elif node.op == '!=':
                        return BoolLiteral(left.value != right.value, line=node.line)
                    elif node.op == '<':
                        return BoolLiteral(left.value < right.value, line=node.line)
                    elif node.op == '>':
                        return BoolLiteral(left.value > right.value, line=node.line)
                    elif node.op == '<=':
                        return BoolLiteral(left.value <= right.value, line=node.line)
                    elif node.op == '>=':
                        return BoolLiteral(left.value >= right.value, line=node.line)
                except:
                    pass  # Keep original if folding fails
            
            # String concatenation
            if isinstance(left, StringLiteral) and isinstance(right, StringLiteral):
                if node.op == '+':
                    return StringLiteral(left.value + right.value, line=node.line)
            
            # Boolean operations
            if isinstance(left, BoolLiteral) and isinstance(right, BoolLiteral):
                if node.op == 'और':
                    return BoolLiteral(left.value and right.value, line=node.line)
                elif node.op == 'अथवा':
                    return BoolLiteral(left.value or right.value, line=node.line)
            
            # Return partially folded expression
            return BinaryExpr(op=node.op, left=left, right=right, line=node.line)
        
        elif isinstance(node, UnaryExpr):
            operand = self._constant_fold(node.operand)
            
            if isinstance(operand, NumberLiteral):
                try:
                    if node.op == '-':
                        return NumberLiteral(-operand.value, line=node.line)
                    elif node.op == 'न':
                        return BoolLiteral(not operand.value, line=node.line)
                except:
                    pass
            
            if isinstance(operand, BoolLiteral):
                if node.op == 'न':
                    return BoolLiteral(not operand.value, line=node.line)
            
            return UnaryExpr(op=node.op, operand=operand, line=node.line)

        elif isinstance(node, ConditionalExpr):
            condition = self._constant_fold(node.condition)
            then_expr = self._constant_fold(node.then_expr)
            else_expr = self._constant_fold(node.else_expr)

            if isinstance(condition, BoolLiteral):
                return then_expr if condition.value else else_expr

            return ConditionalExpr(
                condition=condition,
                then_expr=then_expr,
                else_expr=else_expr,
                line=node.line,
            )
        
        elif isinstance(node, IfStmt):
            # Constant condition optimization
            condition = self._constant_fold(node.condition)
            
            if isinstance(condition, BoolLiteral):
                if condition.value:
                    return self._constant_fold(node.then_body)

                for elif_cond, elif_body in node.elif_clauses:
                    folded_elif_cond = self._constant_fold(elif_cond)
                    if isinstance(folded_elif_cond, BoolLiteral):
                        if folded_elif_cond.value:
                            return self._constant_fold(elif_body)
                        continue

                    remaining_elifs = [
                        (self._constant_fold(c), self._constant_fold(b))
                        for c, b in node.elif_clauses[node.elif_clauses.index((elif_cond, elif_body)) + 1:]
                    ]
                    return IfStmt(
                        condition=folded_elif_cond,
                        then_body=self._constant_fold(elif_body),
                        elif_clauses=remaining_elifs,
                        else_body=self._constant_fold(node.else_body) if node.else_body else None,
                        line=node.line,
                    )

                if node.else_body:
                    return self._constant_fold(node.else_body)

                return Block(stmts=[], line=node.line)
            
            # Recursively fold body
            return IfStmt(
                condition=condition,
                then_body=self._constant_fold(node.then_body),
                elif_clauses=[(self._constant_fold(c), self._constant_fold(b)) 
                             for c, b in node.elif_clauses],
                else_body=self._constant_fold(node.else_body) if node.else_body else None,
                line=node.line
            )
        
        elif isinstance(node, WhileStmt):
            # Constant condition - infinite loop or dead loop
            condition = self._constant_fold(node.condition)
            
            if isinstance(condition, BoolLiteral):
                if not condition.value:
                    # Loop never executes - replace with empty block
                    return Block(stmts=[], line=node.line)
                # else: infinite loop, keep as-is
            
            return WhileStmt(
                condition=condition,
                body=self._constant_fold(node.body),
                line=node.line
            )
        
        elif isinstance(node, Block):
            return Block(
                stmts=[self._constant_fold(stmt) for stmt in node.stmts],
                line=node.line
            )
        
        elif isinstance(node, Program):
            return Program(body=[self._constant_fold(stmt) for stmt in node.body])
        
        elif isinstance(node, FuncDecl):
            return FuncDecl(
                name=node.name,
                params=node.params,
                defaults=node.defaults,
                varargs=node.varargs,
                body=self._constant_fold(node.body),
                return_type=node.return_type,
                is_async=node.is_async,
                line=node.line
            )
        
        # For other nodes, return as-is
        return node

    def _eliminate_dead_code(self):
        """
        Placeholder for dead-code elimination.

        A correct implementation needs instruction-aware control-flow
        analysis. Scanning raw byte values is unsafe because operands may
        legitimately contain the same numeric value as an opcode.
        """
        return


class CompileError(Exception):
    def __init__(self, message: str, line: int = 0):
        self.message = message
        self.line = line
        super().__init__(f"[Line {line}] {message}")
